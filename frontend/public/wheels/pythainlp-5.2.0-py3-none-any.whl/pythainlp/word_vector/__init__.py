# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2016-2025 PyThaiNLP Project
# SPDX-FileType: SOURCE
# SPDX-License-Identifier: Apache-2.0
"""
thai2fit - Thai word vector.

Initial code from https://github.com/cstorm125/thai2fit
"""
__all__ = [
    "WordVector",
]

from pythainlp.word_vector.core import (
    WordVector,
)
