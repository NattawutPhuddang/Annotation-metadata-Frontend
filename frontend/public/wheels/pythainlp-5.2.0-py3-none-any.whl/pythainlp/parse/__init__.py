# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2016-2025 PyThaiNLP Project
# SPDX-FileType: SOURCE
# SPDX-License-Identifier: Apache-2.0

"""
PyThaiNLP Parse
"""
__all__ = ["dependency_parsing"]

from pythainlp.parse.core import dependency_parsing
