# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2016-2025 PyThaiNLP Project
# SPDX-FileType: SOURCE
# SPDX-License-Identifier: Apache-2.0
"""
pythainlp.el
"""

__all__ = ["EntityLinker"]

from pythainlp.el.core import EntityLinker
