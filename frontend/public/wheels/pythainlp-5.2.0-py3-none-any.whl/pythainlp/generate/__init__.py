# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2016-2025 PyThaiNLP Project
# SPDX-FileType: SOURCE
# SPDX-License-Identifier: Apache-2.0
"""
Thai Text Generation
"""

__all__ = ["Bigram", "Trigram", "Unigram"]

from pythainlp.generate.core import Bigram, Trigram, Unigram
