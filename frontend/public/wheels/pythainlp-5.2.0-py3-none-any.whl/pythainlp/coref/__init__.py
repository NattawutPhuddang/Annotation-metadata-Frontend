# -*- coding: utf-8 -*-
# SPDX-FileCopyrightText: 2016-2025 PyThaiNLP Project
# SPDX-FileType: SOURCE
# SPDX-License-Identifier: Apache-2.0
"""
PyThaiNLP Coreference Resolution
"""
__all__ = ["coreference_resolution"]

from pythainlp.coref.core import coreference_resolution
